Surfly Fixed By Pasivraucher
-------------------------------------------------------------
Исправленная версия известного мода на полет Surfly!
В этой версии исправлен баг с бессмертием. Так как в оригинальной версии был этот баг.

Управление.
Клавиша активации: ALT + X
Клавиша дезактивации: X
Зажать ALT для замедления передвижения.
WASD - Клавиши передвижения.
SHIFT - Вниз.
SPACE - Вверх.

Внимание! Советую использовать на DM/Freeoram серверах.

Удачной игры!
-------------------------------------------------------------
Installation Anleitung:
-------------------------------------------------------------
1) Der Autor: OpcodEXE
Auf der Site vom Benutzer hinzugefuegt wurde: Err-Cde
-------------------------------------------------------------
2) Kopieren von Dateien:
Alle Inhalte des Ordners "To copy to game folder" Kopieren Sie in den Spiel-Ordner den Ersatz bestaetigt.

(!) Wenn Sie in der Lage sein, die Aenderung zu entfernen, stellen Sie sicher, dass Sie die Original-Kopien ersetzten Dateien an einem sicheren Ort erhalten.
-------------------------------------------------------------
Diese Modifikation wurde von der Website https://GameModding.com/en/ heruntergeladen\r\nFolgen Sie uns in den sozialen Netzwerken!
http://vk.com/gamemoddingcom
https://twitter.com/GameModdingNet
http://www.facebook.com/gamemodding
http://www.youtube.com/user/GameModdingPreview
