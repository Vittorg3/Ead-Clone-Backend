Surfly Fixed By Pasivraucher
-------------------------------------------------------------
Исправленная версия известного мода на полет Surfly!
В этой версии исправлен баг с бессмертием. Так как в оригинальной версии был этот баг.

Управление.
Клавиша активации: ALT + X
Клавиша дезактивации: X
Зажать ALT для замедления передвижения.
WASD - Клавиши передвижения.
SHIFT - Вниз.
SPACE - Вверх.

Внимание! Советую использовать на DM/Freeoram серверах.

Удачной игры!
-------------------------------------------------------------
Installation instructions:
-------------------------------------------------------------
1) Author: OpcodEXE
Was added to the site by user: Err-Cde
-------------------------------------------------------------
2) Copying files:
All contents of the folder "To copy to game folder" copy into the game folder confirming the replacement.

(!) If You wish to be able to remove a modification, make sure You save original copies of the replaced files safely.
-------------------------------------------------------------
This modification was downloaded from https://GameModding.com/ website
Follow us in social networks!
http://vk.com/gamemoddingcom
https://twitter.com/GameModdingNet
http://www.facebook.com/gamemodding
http://www.youtube.com/user/GameModdingPreview
